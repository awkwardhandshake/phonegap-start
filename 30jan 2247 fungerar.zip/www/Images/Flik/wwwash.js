﻿

function initCalendar()
{
	tbl1.cellSpacing = 0;
}


function resetTimeOut()
{
	if(top.inactiveSeconds != null)
	{
		top.resetTimer();
	}
}

function OpenTheHelpWindow(theHelp)
{
	window.open(theHelp, '', 'width=600,height=500,scrollbars=yes');
}
		


