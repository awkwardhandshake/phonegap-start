function raderaallt(){
	localStorage.clear();
	location.reload();
}